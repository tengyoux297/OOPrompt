(function(){chrome.runtime.onMessage.addListener((t,o,n)=>{if(t.type==="PING")return n({success:!0,loaded:!0}),!0;if(t.type==="INJECT_PROMPT"){try{u(t.prompt),n({success:!0})}catch(r){console.error("Failed to inject prompt:",r),n({success:!1,error:r instanceof Error?r.message:"Unknown error"})}return!0}return!1});function u(t){const o=document.querySelectorAll("textarea"),n=document.querySelectorAll('input[type="text"], input[type="search"]'),r=document.querySelectorAll('[contenteditable="true"]');if(o.length>0){let e=null,a=0;if(o.forEach(s=>{const c=s.offsetWidth*s.offsetHeight;c>a&&s.offsetParent!==null&&(a=c,e=s)}),e){e.value=t,e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0})),e.focus();return}}if(r.length>0){const e=r[0];e.textContent=t,e.dispatchEvent(new Event("input",{bubbles:!0})),e.focus();return}if(n.length>0){const e=n[0];e.value=t,e.dispatchEvent(new Event("input",{bubbles:!0})),e.dispatchEvent(new Event("change",{bubbles:!0})),e.focus();return}const i=document.createElement("textarea");i.value=t,i.style.position="fixed",i.style.opacity="0",document.body.appendChild(i),i.select(),document.execCommand("copy"),document.body.removeChild(i),l("Prompt copied to clipboard! Paste it into the input field.")}function l(t){const o=document.createElement("div");o.textContent=t,o.style.cssText=`
    position: fixed;
    top: 20px;
    right: 20px;
    background: #10b981;
    color: white;
    padding: 12px 20px;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    z-index: 10000;
    font-family: system-ui, -apple-system, sans-serif;
    font-size: 14px;
    animation: slideIn 0.3s ease-out;
  `;const n=document.createElement("style");n.textContent=`
    @keyframes slideIn {
      from {
        transform: translateX(100%);
        opacity: 0;
      }
      to {
        transform: translateX(0);
        opacity: 1;
      }
    }
  `,document.head.appendChild(n),document.body.appendChild(o),setTimeout(()=>{o.style.animation="slideIn 0.3s ease-out reverse",setTimeout(()=>{document.body.removeChild(o),document.head.removeChild(n)},300)},3e3)}
})()
